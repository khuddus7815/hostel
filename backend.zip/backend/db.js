const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: 'sdb-87.hosting.stackcp.net',
  user: 'tranetra',
  password: 'y*rIWWOqA9!T',
  database: 'tranetra-35313133cb7c',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

module.exports = {
  pool
};